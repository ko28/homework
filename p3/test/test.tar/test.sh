uname -rs
echo "hello friends!"
